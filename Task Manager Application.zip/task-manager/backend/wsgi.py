from app import create_app
from app.extensions import socketio

app = create_app()

if __name__ == "__main__":
    # Development server. In Docker, gunicorn runs `wsgi:app` instead.
    socketio.run(app, host="0.0.0.0", port=5000, debug=True, allow_unsafe_werkzeug=True)
