from datetime import date

from flask import Blueprint, jsonify, request
from flask_jwt_extended import get_jwt_identity, jwt_required
from sqlalchemy import case, func, or_

from ..extensions import db, socketio
from ..models import Task

bp = Blueprint("tasks", __name__, url_prefix="/api/tasks")


def _uid():
    return int(get_jwt_identity())


def _room(user_id):
    return f"user_{user_id}"


def _broadcast(event, payload, user_id):
    """Push a change to every open session of this user (tabs, devices)."""
    socketio.emit(event, payload, to=_room(user_id))


def _parse(data, partial=False):
    """Validate an incoming task payload. partial=True for PATCH."""
    out, errors = {}, {}

    if "title" in data or not partial:
        title = (data.get("title") or "").strip()
        if not title:
            errors["title"] = "Title is required."
        elif len(title) > 200:
            errors["title"] = "Title must be 200 characters or fewer."
        else:
            out["title"] = title

    if "description" in data:
        out["description"] = (data.get("description") or "").strip() or None

    if "status" in data:
        if data["status"] not in Task.STATUSES:
            errors["status"] = f"Status must be one of: {', '.join(Task.STATUSES)}."
        else:
            out["status"] = data["status"]

    if "priority" in data:
        if data["priority"] not in Task.PRIORITIES:
            errors["priority"] = f"Priority must be one of: {', '.join(Task.PRIORITIES)}."
        else:
            out["priority"] = data["priority"]

    if "due_date" in data:
        value = data["due_date"]
        if value in (None, ""):
            out["due_date"] = None
        else:
            try:
                out["due_date"] = date.fromisoformat(value)
            except (TypeError, ValueError):
                errors["due_date"] = "Due date must be in YYYY-MM-DD format."

    return out, errors


def _get_owned(task_id):
    return Task.query.filter_by(id=task_id, user_id=_uid()).first()


@bp.get("")
@jwt_required()
def list_tasks():
    query = Task.query.filter_by(user_id=_uid())

    status = request.args.get("status")
    if status in Task.STATUSES:
        query = query.filter(Task.status == status)

    priority = request.args.get("priority")
    if priority in Task.PRIORITIES:
        query = query.filter(Task.priority == priority)

    search = (request.args.get("search") or "").strip()
    if search:
        like = f"%{search}%"
        query = query.filter(or_(Task.title.ilike(like), Task.description.ilike(like)))

    priority_rank = case({"high": 0, "medium": 1, "low": 2}, value=Task.priority)
    sorts = {
        "created_desc": [Task.created_at.desc(), Task.id.desc()],
        "created_asc": [Task.created_at.asc(), Task.id.asc()],
        # MySQL has no NULLS LAST, so sort on "is null" first
        "due_asc": [Task.due_date.is_(None), Task.due_date.asc(), Task.id.desc()],
        "priority": [priority_rank, Task.created_at.desc()],
    }
    query = query.order_by(*sorts.get(request.args.get("sort"), sorts["created_desc"]))

    tasks = query.all()
    return jsonify(tasks=[t.to_dict() for t in tasks], count=len(tasks))


@bp.get("/stats")
@jwt_required()
def stats():
    uid = _uid()

    by_status = {s: 0 for s in Task.STATUSES}
    for status, count in (
        db.session.query(Task.status, func.count(Task.id)).filter(Task.user_id == uid).group_by(Task.status)
    ):
        by_status[status] = count

    by_priority = {p: 0 for p in Task.PRIORITIES}
    for priority, count in (
        db.session.query(Task.priority, func.count(Task.id)).filter(Task.user_id == uid).group_by(Task.priority)
    ):
        by_priority[priority] = count

    overdue = Task.query.filter(
        Task.user_id == uid, Task.status != "done", Task.due_date.isnot(None), Task.due_date < date.today()
    ).count()

    total = sum(by_status.values())
    return jsonify(
        total=total,
        by_status=by_status,
        by_priority=by_priority,
        overdue=overdue,
        completion_rate=round(by_status["done"] / total * 100, 1) if total else 0,
    )


@bp.get("/<int:task_id>")
@jwt_required()
def get_task(task_id):
    task = _get_owned(task_id)
    if not task:
        return jsonify(error="Task not found."), 404
    return jsonify(task=task.to_dict())


@bp.post("")
@jwt_required()
def create_task():
    fields, errors = _parse(request.get_json(silent=True) or {})
    if errors:
        return jsonify(error="Please fix the highlighted fields.", details=errors), 400

    task = Task(user_id=_uid(), **fields)
    db.session.add(task)
    db.session.commit()

    _broadcast("task_created", {"task": task.to_dict()}, task.user_id)
    return jsonify(task=task.to_dict()), 201


@bp.route("/<int:task_id>", methods=["PUT", "PATCH"])
@jwt_required()
def update_task(task_id):
    task = _get_owned(task_id)
    if not task:
        return jsonify(error="Task not found."), 404

    fields, errors = _parse(request.get_json(silent=True) or {}, partial=request.method == "PATCH")
    if errors:
        return jsonify(error="Please fix the highlighted fields.", details=errors), 400

    for key, value in fields.items():
        setattr(task, key, value)
    db.session.commit()

    _broadcast("task_updated", {"task": task.to_dict()}, task.user_id)
    return jsonify(task=task.to_dict())


@bp.delete("/<int:task_id>")
@jwt_required()
def delete_task(task_id):
    task = _get_owned(task_id)
    if not task:
        return jsonify(error="Task not found."), 404

    user_id = task.user_id
    db.session.delete(task)
    db.session.commit()

    _broadcast("task_deleted", {"id": task_id}, user_id)
    return "", 204
