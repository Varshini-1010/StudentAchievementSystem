import time

from flask import Flask, jsonify, request
from sqlalchemy.exc import OperationalError

from config import Config

from .extensions import cors, db, jwt, socketio
from . import sockets  # noqa: F401  register socket handlers before init_app


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    jwt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})
    socketio.init_app(app, cors_allowed_origins=app.config["CORS_ORIGINS"], async_mode="threading")

    from .routes import auth, tasks

    app.register_blueprint(auth.bp)
    app.register_blueprint(tasks.bp)

    _register_error_handlers(app)

    @app.get("/api/health")
    def health():
        return jsonify(status="ok")

    with app.app_context():
        _init_db(app)

    return app


def _register_error_handlers(app):
    @jwt.unauthorized_loader
    def missing_token(reason):
        return jsonify(error="Sign in to continue."), 401

    @jwt.invalid_token_loader
    def invalid_token(reason):
        return jsonify(error="Your session is invalid. Sign in again."), 401

    @jwt.expired_token_loader
    def expired_token(header, payload):
        return jsonify(error="Your session has expired. Sign in again."), 401

    @app.errorhandler(404)
    def not_found(err):
        if request.path.startswith("/api/"):
            return jsonify(error="Endpoint not found."), 404
        return err

    @app.errorhandler(405)
    def not_allowed(err):
        return jsonify(error="Method not allowed."), 405

    @app.errorhandler(500)
    def server_error(err):
        db.session.rollback()
        return jsonify(error="Something went wrong on the server."), 500


def _init_db(app, retries=15, delay=2):
    """MySQL may still be booting when the container starts, so retry."""
    for attempt in range(1, retries + 1):
        try:
            db.create_all()
            return
        except OperationalError:
            if attempt == retries:
                raise
            app.logger.warning("Database not ready (attempt %s/%s), retrying...", attempt, retries)
            time.sleep(delay)
