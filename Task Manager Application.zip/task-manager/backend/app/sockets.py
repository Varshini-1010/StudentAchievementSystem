"""WebSocket layer. Each authenticated connection joins a private room
named after its user, so task events only reach the owner's sessions."""
from flask_jwt_extended import decode_token
from flask_socketio import join_room

from .extensions import socketio


@socketio.on("connect")
def on_connect(auth):
    token = (auth or {}).get("token")
    if not token:
        return False  # reject unauthenticated sockets
    try:
        claims = decode_token(token)
    except Exception:
        return False
    join_room(f"user_{claims['sub']}")
