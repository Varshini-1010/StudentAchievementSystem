import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app  # noqa: E402
from app.extensions import db  # noqa: E402
from config import TestConfig  # noqa: E402


@pytest.fixture
def app():
    app = create_app(TestConfig)
    yield app
    with app.app_context():
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def register(client, username="alice", email="alice@example.com", password="password123"):
    res = client.post("/api/auth/register", json={"username": username, "email": email, "password": password})
    return res


@pytest.fixture
def auth_headers(client):
    token = register(client).get_json()["token"]
    return {"Authorization": f"Bearer {token}"}
