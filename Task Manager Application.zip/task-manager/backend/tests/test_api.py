from datetime import date, timedelta

from app.extensions import socketio

from .conftest import register


def test_register_login_and_me(client):
    assert register(client).status_code == 201
    assert register(client).status_code == 409  # duplicate

    res = client.post("/api/auth/login", json={"email": "alice@example.com", "password": "password123"})
    assert res.status_code == 200
    token = res.get_json()["token"]

    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.get_json()["user"]["username"] == "alice"


def test_bad_login_and_validation(client):
    register(client)
    assert client.post("/api/auth/login", json={"email": "alice@example.com", "password": "nope"}).status_code == 401
    res = client.post("/api/auth/register", json={"username": "a", "email": "bad", "password": "x"})
    assert res.status_code == 400
    assert set(res.get_json()["details"]) == {"username", "email", "password"}


def test_tasks_require_auth(client):
    assert client.get("/api/tasks").status_code == 401


def test_crud(client, auth_headers):
    res = client.post("/api/tasks", json={"title": "Write report", "priority": "high"}, headers=auth_headers)
    assert res.status_code == 201
    task = res.get_json()["task"]
    assert task["status"] == "todo"

    res = client.patch(f"/api/tasks/{task['id']}", json={"status": "done"}, headers=auth_headers)
    assert res.get_json()["task"]["status"] == "done"

    assert client.get(f"/api/tasks/{task['id']}", headers=auth_headers).status_code == 200
    assert client.delete(f"/api/tasks/{task['id']}", headers=auth_headers).status_code == 204
    assert client.get(f"/api/tasks/{task['id']}", headers=auth_headers).status_code == 404


def test_invalid_task_payload(client, auth_headers):
    res = client.post("/api/tasks", json={"title": "", "status": "nope", "due_date": "tomorrow"}, headers=auth_headers)
    assert res.status_code == 400
    assert set(res.get_json()["details"]) == {"title", "status", "due_date"}


def test_filter_search_and_stats(client, auth_headers):
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    for body in [
        {"title": "Fix login bug", "priority": "high", "due_date": yesterday},
        {"title": "Buy milk", "priority": "low", "status": "done"},
        {"title": "Plan sprint", "description": "login flow review", "status": "in_progress"},
    ]:
        client.post("/api/tasks", json=body, headers=auth_headers)

    tasks = client.get("/api/tasks?search=login", headers=auth_headers).get_json()["tasks"]
    assert {t["title"] for t in tasks} == {"Fix login bug", "Plan sprint"}

    tasks = client.get("/api/tasks?priority=high", headers=auth_headers).get_json()["tasks"]
    assert len(tasks) == 1 and tasks[0]["is_overdue"]

    tasks = client.get("/api/tasks?sort=priority", headers=auth_headers).get_json()["tasks"]
    assert [t["priority"] for t in tasks] == ["high", "medium", "low"]

    stats = client.get("/api/tasks/stats", headers=auth_headers).get_json()
    assert stats["total"] == 3
    assert stats["by_status"] == {"todo": 1, "in_progress": 1, "done": 1}
    assert stats["overdue"] == 1
    assert stats["completion_rate"] == 33.3


def test_users_cannot_see_each_others_tasks(client, auth_headers):
    task_id = client.post("/api/tasks", json={"title": "Private"}, headers=auth_headers).get_json()["task"]["id"]
    bob = register(client, "bob", "bob@example.com").get_json()["token"]
    bob_headers = {"Authorization": f"Bearer {bob}"}
    assert client.get("/api/tasks", headers=bob_headers).get_json()["count"] == 0
    assert client.delete(f"/api/tasks/{task_id}", headers=bob_headers).status_code == 404


def test_websocket_auth_and_events(app, client, auth_headers):
    token = auth_headers["Authorization"].split()[1]

    rejected = socketio.test_client(app, auth={})
    assert not rejected.is_connected()

    ws = socketio.test_client(app, auth={"token": token})
    assert ws.is_connected()
    client.post("/api/tasks", json={"title": "Realtime"}, headers=auth_headers)
    events = [e["name"] for e in ws.get_received()]
    assert "task_created" in events
    ws.disconnect()
