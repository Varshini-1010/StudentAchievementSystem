# Task Manager

Full-stack task manager: **Flask + MySQL** API with JWT auth and Socket.IO real-time updates, and a **React + Tailwind CSS** dashboard. Runs with one `docker compose up`.

## Run with Docker (recommended)

```bash
cp .env.example .env        # edit secrets
docker compose up --build
```

Open http://localhost:3000, create an account, and add tasks. Open a second tab: changes appear in both instantly.

## Run locally without Docker

You need Python 3.12, Node 20 and a MySQL server.

```bash
# 1. Database
mysql -u root -p -e "CREATE DATABASE taskdb; CREATE USER 'taskuser'@'localhost' IDENTIFIED BY 'taskpass'; GRANT ALL ON taskdb.* TO 'taskuser'@'localhost';"

# 2. Backend (http://localhost:5000)
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python wsgi.py

# 3. Frontend (http://localhost:5173) — in a new terminal
cd frontend
npm install
npm run dev
```

## Tests

```bash
cd backend && pytest -q
```

Tests use in-memory SQLite, so no MySQL is needed. They cover auth, validation, CRUD, filtering, sorting, stats, per-user isolation and WebSocket auth/events.

## API

All `/api/tasks` routes need `Authorization: Bearer <token>`.

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create account → `{token, user}` |
| POST | `/api/auth/login` | Sign in → `{token, user}` |
| GET | `/api/auth/me` | Current user |
| GET | `/api/tasks?status=&priority=&search=&sort=` | List with filters (`sort`: `created_desc`, `created_asc`, `due_asc`, `priority`) |
| GET | `/api/tasks/stats` | Counts by status/priority, overdue, completion rate |
| GET | `/api/tasks/:id` | One task |
| POST | `/api/tasks` | Create |
| PATCH / PUT | `/api/tasks/:id` | Update (PATCH = partial) |
| DELETE | `/api/tasks/:id` | Delete |
| GET | `/api/health` | Health check |

**WebSocket events** (Socket.IO, connect with `auth: { token }`): `task_created`, `task_updated`, `task_deleted`. Each user only receives their own events.

## Project structure

```
backend/
  app/__init__.py      app factory, error handlers, DB init with retry
  app/extensions.py    db, jwt, socketio, cors instances
  app/models.py        User, Task
  app/routes/auth.py   register / login / me
  app/routes/tasks.py  CRUD, filters, stats, broadcasts
  app/sockets.py       JWT-checked socket connect, per-user rooms
  config.py, wsgi.py, tests/
frontend/
  src/api.js                 fetch wrapper + token storage
  src/context/AuthContext    session state
  src/hooks/useTaskSocket    live updates
  src/pages/                 AuthPage, Dashboard
  src/components/            Header, ProgressOverview, FilterBar, TaskRow, TaskModal
  nginx.conf                 serves the build, proxies /api and /socket.io
docker-compose.yml
```

## Going further

- Use Flask-Migrate (Alembic) instead of `db.create_all()` once the schema starts changing.
- To run several backend workers, add Redis and pass `message_queue="redis://..."` to SocketIO.
- Put HTTPS in front (Caddy, Traefik or a cloud load balancer) before going public.
