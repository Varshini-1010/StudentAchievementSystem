import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function AuthPage({ mode }) {
  const isLogin = mode === "login";
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const [busy, setBusy] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    setFieldErrors({});
    try {
      if (isLogin) await login(form.email, form.password);
      else await register(form.username, form.email, form.password);
      navigate("/", { replace: true });
    } catch (err) {
      setError(err.message);
      setFieldErrors(err.details || {});
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="grid min-h-screen place-items-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-ink text-lg font-extrabold text-marigold">✓</span>
          <span className="text-xl font-bold tracking-tight">Tasks</span>
        </div>

        <h1 className="text-3xl font-bold tracking-tight">{isLogin ? "Sign in" : "Create your account"}</h1>
        <p className="mt-2 text-ink-soft">
          {isLogin ? "Pick up where you left off." : "Start organising your work in under a minute."}
        </p>

        <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
          {!isLogin && (
            <Field label="Username" error={fieldErrors.username}>
              <input className="field" value={form.username} onChange={set("username")} autoComplete="username" required />
            </Field>
          )}
          <Field label="Email" error={fieldErrors.email}>
            <input className="field" type="email" value={form.email} onChange={set("email")} autoComplete="email" required />
          </Field>
          <Field label="Password" error={fieldErrors.password} hint={!isLogin ? "At least 8 characters." : undefined}>
            <input
              className="field"
              type="password"
              value={form.password}
              onChange={set("password")}
              autoComplete={isLogin ? "current-password" : "new-password"}
              required
            />
          </Field>

          {error && <p role="alert" className="rounded-md bg-high/10 px-3 py-2 text-sm text-high">{error}</p>}

          <button type="submit" className="btn-primary w-full py-2.5" disabled={busy}>
            {busy ? "Please wait…" : isLogin ? "Sign in" : "Create account"}
          </button>
        </form>

        <p className="mt-6 text-sm text-ink-soft">
          {isLogin ? "New here? " : "Already have an account? "}
          <Link to={isLogin ? "/register" : "/login"} className="font-semibold text-ink underline underline-offset-4">
            {isLogin ? "Create an account" : "Sign in"}
          </Link>
        </p>
      </div>
    </main>
  );
}

function Field({ label, error, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      {children}
      {error ? <span className="mt-1 block text-xs text-high">{error}</span> : hint && <span className="mt-1 block text-xs text-ink-soft">{hint}</span>}
    </label>
  );
}
