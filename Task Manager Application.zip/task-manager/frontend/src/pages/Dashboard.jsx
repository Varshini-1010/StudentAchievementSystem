import { useCallback, useEffect, useMemo, useState } from "react";
import { taskApi } from "../api";
import FilterBar from "../components/FilterBar";
import Header from "../components/Header";
import ProgressOverview from "../components/ProgressOverview";
import TaskModal from "../components/TaskModal";
import TaskRow from "../components/TaskRow";
import { useAuth } from "../context/AuthContext";
import { useDebounce } from "../hooks/useDebounce";
import { useTaskSocket } from "../hooks/useTaskSocket";

const DEFAULT_FILTERS = { search: "", status: "", priority: "", sort: "created_desc" };

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null); // null = closed, {} = new, task = edit

  const search = useDebounce(filters.search, 300);

  const query = useMemo(() => {
    const q = { sort: filters.sort };
    if (search.trim()) q.search = search.trim();
    if (filters.status) q.status = filters.status;
    if (filters.priority) q.priority = filters.priority;
    return q;
  }, [search, filters.status, filters.priority, filters.sort]);

  // Tasks and stats are always re-read from the server, so the view stays
  // correct no matter which tab or device made the change.
  const refresh = useCallback(async () => {
    try {
      const [list, s] = await Promise.all([taskApi.list(query), taskApi.stats()]);
      setTasks(list.tasks);
      setStats(s);
      setError("");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const connected = useTaskSocket(refresh);

  const closeModal = useCallback(() => setEditing(null), []);

  const saveTask = async (data) => {
    if (editing?.id) await taskApi.update(editing.id, data);
    else await taskApi.create(data);
    setEditing(null);
    refresh();
  };

  const changeStatus = async (task, status) => {
    setTasks((ts) => ts.map((t) => (t.id === task.id ? { ...t, status } : t))); // optimistic
    try {
      await taskApi.update(task.id, { status });
    } catch (err) {
      setError(err.message);
    }
    refresh();
  };

  const deleteTask = async (task) => {
    if (!window.confirm(`Delete "${task.title}"? This can't be undone.`)) return;
    try {
      await taskApi.remove(task.id);
    } catch (err) {
      setError(err.message);
    }
    refresh();
  };

  const filtered = filters.search || filters.status || filters.priority;

  return (
    <div className="min-h-screen">
      <Header user={user} connected={connected} onLogout={logout} onNewTask={() => setEditing({})} />

      <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 sm:px-6 sm:py-8">
        <ProgressOverview stats={stats} />

        <FilterBar filters={filters} onChange={setFilters} onReset={() => setFilters(DEFAULT_FILTERS)} count={tasks.length} />

        {error && (
          <div role="alert" className="flex items-center justify-between rounded-md bg-high/10 px-4 py-3 text-sm text-high">
            {error}
            <button className="font-semibold underline" onClick={refresh}>Try again</button>
          </div>
        )}

        <section aria-label="Tasks" className="overflow-hidden rounded-xl border border-line">
          {loading ? (
            <p className="bg-white p-8 text-center text-ink-soft">Loading tasks…</p>
          ) : tasks.length === 0 ? (
            <div className="bg-white px-6 py-14 text-center">
              <p className="text-lg font-semibold">{filtered ? "No tasks match these filters" : "No tasks yet"}</p>
              <p className="mt-1 text-sm text-ink-soft">
                {filtered ? "Try a different search, or clear the filters." : "Add your first task to start tracking progress."}
              </p>
              <button className="btn-primary mt-5" onClick={() => (filtered ? setFilters(DEFAULT_FILTERS) : setEditing({}))}>
                {filtered ? "Clear filters" : "New task"}
              </button>
            </div>
          ) : (
            <ul>
              {tasks.map((t) => (
                <TaskRow key={t.id} task={t} onEdit={setEditing} onDelete={deleteTask} onStatusChange={changeStatus} />
              ))}
            </ul>
          )}
        </section>
      </main>

      {editing && <TaskModal task={editing} onClose={closeModal} onSave={saveTask} />}
    </div>
  );
}
