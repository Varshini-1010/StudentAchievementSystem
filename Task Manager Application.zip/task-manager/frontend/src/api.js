const TOKEN_KEY = "tm_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => localStorage.setItem(TOKEN_KEY, t);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

export class ApiError extends Error {
  constructor(message, status, details) {
    super(message);
    this.status = status;
    this.details = details || {};
  }
}

async function request(path, { method = "GET", body } = {}) {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(`/api${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new ApiError("Can't reach the server. Check your connection.", 0);
  }

  const data = res.status === 204 ? null : await res.json().catch(() => null);

  if (!res.ok) {
    // An expired/invalid token on a protected call logs the user out everywhere.
    if (res.status === 401 && token && !path.startsWith("/auth/login")) {
      clearToken();
      window.dispatchEvent(new Event("auth:logout"));
    }
    throw new ApiError(data?.error || "Request failed.", res.status, data?.details);
  }
  return data;
}

export const authApi = {
  login: (email, password) => request("/auth/login", { method: "POST", body: { email, password } }),
  register: (username, email, password) =>
    request("/auth/register", { method: "POST", body: { username, email, password } }),
  me: () => request("/auth/me"),
};

export const taskApi = {
  list: (params = {}) => request(`/tasks?${new URLSearchParams(params)}`),
  stats: () => request("/tasks/stats"),
  create: (task) => request("/tasks", { method: "POST", body: task }),
  update: (id, changes) => request(`/tasks/${id}`, { method: "PATCH", body: changes }),
  remove: (id) => request(`/tasks/${id}`, { method: "DELETE" }),
};
