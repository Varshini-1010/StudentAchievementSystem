import { STATUSES } from "../constants";

/** The dashboard's lead element: completion rate plus one bar split by status. */
export default function ProgressOverview({ stats }) {
  if (!stats) return <div className="h-44 animate-pulse rounded-xl bg-white/60" />;

  const { total, by_status, by_priority, overdue, completion_rate } = stats;

  return (
    <section className="rounded-xl bg-ink p-6 text-white sm:p-8" aria-label="Progress overview">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="text-sm text-white/60">Completed</p>
          <p className="text-6xl font-extrabold leading-none tracking-tight sm:text-7xl">
            {Math.round(completion_rate)}
            <span className="text-3xl text-marigold sm:text-4xl">%</span>
          </p>
          <p className="mt-2 text-sm text-white/70">
            {by_status.done} of {total} {total === 1 ? "task" : "tasks"} done
          </p>
        </div>

        <dl className="grid grid-cols-3 gap-6 text-sm">
          <Stat label="High priority" value={by_priority.high} />
          <Stat label="In progress" value={by_status.in_progress} />
          <Stat label="Overdue" value={overdue} warn={overdue > 0} />
        </dl>
      </div>

      <div className="mt-8 flex h-3 overflow-hidden rounded-full bg-white/10" role="img"
        aria-label={STATUSES.map((s) => `${s.label}: ${by_status[s.value]}`).join(", ")}>
        {total > 0 &&
          STATUSES.map((s) => (
            <div key={s.value} className={`${s.color} transition-all duration-500`}
              style={{ width: `${(by_status[s.value] / total) * 100}%` }} />
          ))}
      </div>
      <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-white/70">
        {STATUSES.map((s) => (
          <li key={s.value} className="flex items-center gap-1.5">
            <span className={`h-2 w-2 rounded-full ${s.color}`} />
            {s.label} <span className="font-semibold text-white">{by_status[s.value]}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Stat({ label, value, warn }) {
  return (
    <div>
      <dt className="text-white/60">{label}</dt>
      <dd className={`text-2xl font-bold ${warn ? "text-marigold" : ""}`}>{value}</dd>
    </div>
  );
}
