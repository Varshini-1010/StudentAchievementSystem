import { PRIORITIES, SORTS, STATUSES } from "../constants";

export default function FilterBar({ filters, onChange, onReset, count }) {
  const set = (key) => (e) => onChange({ ...filters, [key]: e.target.value });
  const active = filters.search || filters.status || filters.priority;

  return (
    <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
      <div className="relative flex-1">
        <svg className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path fillRule="evenodd" d="M9 3.5a5.5 5.5 0 1 0 3.47 9.77l3.63 3.63a.75.75 0 1 0 1.06-1.06l-3.63-3.63A5.5 5.5 0 0 0 9 3.5ZM5 9a4 4 0 1 1 8 0 4 4 0 0 1-8 0Z" clipRule="evenodd" />
        </svg>
        <input className="field pl-9" placeholder="Search titles and descriptions" value={filters.search}
          onChange={set("search")} aria-label="Search tasks" />
      </div>
      <div className="grid grid-cols-3 gap-2 lg:flex">
        <select className="field lg:w-36" value={filters.status} onChange={set("status")} aria-label="Filter by status">
          <option value="">Any status</option>
          {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <select className="field lg:w-36" value={filters.priority} onChange={set("priority")} aria-label="Filter by priority">
          <option value="">Any priority</option>
          {PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>
        <select className="field lg:w-40" value={filters.sort} onChange={set("sort")} aria-label="Sort tasks">
          {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>
      <div className="flex items-center gap-3 text-sm text-ink-soft lg:ml-2">
        <span className="whitespace-nowrap">{count} shown</span>
        {active && <button className="font-medium text-ink underline underline-offset-4" onClick={onReset}>Clear filters</button>}
      </div>
    </div>
  );
}
