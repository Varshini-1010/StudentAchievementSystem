import { STATUSES, priorityOf } from "../constants";

const formatDate = (iso) =>
  new Date(`${iso}T00:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

export default function TaskRow({ task, onEdit, onDelete, onStatusChange }) {
  const priority = priorityOf(task.priority);
  const done = task.status === "done";

  return (
    <li className="group relative flex gap-4 border-b border-line bg-white py-4 pl-5 pr-4 last:border-b-0">
      <span className={`absolute inset-y-0 left-0 w-1 ${priority.color}`} aria-hidden="true" />

      <button
        onClick={() => onStatusChange(task, done ? "todo" : "done")}
        className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 ${
          done ? "border-done bg-done text-white" : "border-line hover:border-done"
        }`}
        aria-label={done ? `Mark "${task.title}" as not done` : `Mark "${task.title}" as done`}
      >
        {done && <svg viewBox="0 0 12 12" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2"><path d="m2.5 6 2.5 2.5 4.5-5" /></svg>}
      </button>

      <div className="min-w-0 flex-1">
        <button onClick={() => onEdit(task)} className="text-left">
          <h3 className={`font-semibold leading-snug ${done ? "text-ink-soft line-through" : ""}`}>{task.title}</h3>
        </button>
        {task.description && <p className="mt-1 line-clamp-2 max-w-prose text-sm text-ink-soft">{task.description}</p>}
        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
          <span className={`font-semibold ${priority.text}`}>{priority.label} priority</span>
          {task.due_date && (
            <span className={task.is_overdue ? "font-semibold text-high" : "text-ink-soft"}>
              {task.is_overdue ? "Overdue since " : "Due "}
              {formatDate(task.due_date)}
            </span>
          )}
        </div>
      </div>

      <div className="flex shrink-0 flex-col items-end gap-2 sm:flex-row sm:items-center">
        <select
          value={task.status}
          onChange={(e) => onStatusChange(task, e.target.value)}
          className="rounded-md border border-line bg-mist/60 px-2 py-1 text-xs font-medium"
          aria-label={`Status of "${task.title}"`}
        >
          {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <div className="flex gap-1 sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100">
          <button className="btn-ghost px-2 py-1 text-xs" onClick={() => onEdit(task)}>Edit</button>
          <button className="btn-ghost px-2 py-1 text-xs hover:text-high" onClick={() => onDelete(task)}>Delete</button>
        </div>
      </div>
    </li>
  );
}
