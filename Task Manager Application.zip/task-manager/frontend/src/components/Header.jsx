export default function Header({ user, connected, onLogout, onNewTask }) {
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-mist/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-ink font-extrabold text-marigold">✓</span>
          <span className="text-lg font-bold tracking-tight">Tasks</span>
          <span
            className="ml-2 hidden items-center gap-1.5 text-xs text-ink-soft sm:inline-flex"
            title={connected ? "Changes from your other tabs and devices appear instantly" : "Reconnecting to live updates"}
          >
            <span className={`h-2 w-2 rounded-full ${connected ? "bg-done" : "bg-todo"}`} />
            {connected ? "Live" : "Offline"}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-primary" onClick={onNewTask}>New task</button>
          <span className="hidden text-sm text-ink-soft md:inline">{user.username}</span>
          <button className="btn-ghost" onClick={onLogout}>Sign out</button>
        </div>
      </div>
    </header>
  );
}
