import { useEffect, useRef, useState } from "react";
import { PRIORITIES, STATUSES } from "../constants";

const EMPTY = { title: "", description: "", status: "todo", priority: "medium", due_date: "" };

export default function TaskModal({ task, onClose, onSave }) {
  const isEdit = Boolean(task?.id);
  const [form, setForm] = useState(() => (isEdit ? { ...EMPTY, ...task, description: task.description || "", due_date: task.due_date || "" } : EMPTY));
  const [errors, setErrors] = useState({});
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const titleRef = useRef(null);

  useEffect(() => {
    titleRef.current?.focus();
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      setErrors({ title: "Title is required." });
      return;
    }
    setBusy(true);
    setError("");
    try {
      const { title, description, status, priority, due_date } = form;
      await onSave({ title, description, status, priority, due_date: due_date || null });
    } catch (err) {
      setError(err.message);
      setErrors(err.details || {});
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4" onMouseDown={onClose}>
      <form
        onSubmit={submit}
        onMouseDown={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-t-2xl bg-white p-6 shadow-xl sm:rounded-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="task-modal-title"
        noValidate
      >
        <h2 id="task-modal-title" className="text-xl font-bold">{isEdit ? "Edit task" : "New task"}</h2>

        <div className="mt-5 space-y-4">
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium">Title</span>
            <input ref={titleRef} className="field" value={form.title} onChange={set("title")} maxLength={200} placeholder="What needs doing?" />
            {errors.title && <span className="mt-1 block text-xs text-high">{errors.title}</span>}
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium">Description <span className="font-normal text-ink-soft">(optional)</span></span>
            <textarea className="field min-h-24 resize-y" value={form.description} onChange={set("description")} placeholder="Add details, links or notes" />
          </label>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <label className="block">
              <span className="mb-1.5 block text-sm font-medium">Status</span>
              <select className="field" value={form.status} onChange={set("status")}>
                {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="mb-1.5 block text-sm font-medium">Priority</span>
              <select className="field" value={form.priority} onChange={set("priority")}>
                {PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="mb-1.5 block text-sm font-medium">Due date</span>
              <input type="date" className="field" value={form.due_date} onChange={set("due_date")} />
              {errors.due_date && <span className="mt-1 block text-xs text-high">{errors.due_date}</span>}
            </label>
          </div>

          {error && <p role="alert" className="rounded-md bg-high/10 px-3 py-2 text-sm text-high">{error}</p>}
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-primary" disabled={busy}>
            {busy ? "Saving…" : isEdit ? "Save changes" : "Create task"}
          </button>
        </div>
      </form>
    </div>
  );
}
