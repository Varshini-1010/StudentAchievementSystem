import { useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";
import { getToken } from "../api";

const EVENTS = ["task_created", "task_updated", "task_deleted"];

/** Opens an authenticated Socket.IO connection and calls onChange for every task event. */
export function useTaskSocket(onChange) {
  const [connected, setConnected] = useState(false);
  const callback = useRef(onChange);

  useEffect(() => {
    callback.current = onChange;
  });

  useEffect(() => {
    const token = getToken();
    if (!token) return undefined;

    const socket = io({ auth: { token }, transports: ["websocket", "polling"] });
    socket.on("connect", () => setConnected(true));
    socket.on("disconnect", () => setConnected(false));
    EVENTS.forEach((name) => socket.on(name, (payload) => callback.current?.({ type: name, ...payload })));

    return () => socket.disconnect();
  }, []);

  return connected;
}
