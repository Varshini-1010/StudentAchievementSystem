export const STATUSES = [
  { value: "todo", label: "To do", color: "bg-todo" },
  { value: "in_progress", label: "In progress", color: "bg-doing" },
  { value: "done", label: "Done", color: "bg-done" },
];

export const PRIORITIES = [
  { value: "high", label: "High", color: "bg-high", text: "text-high" },
  { value: "medium", label: "Medium", color: "bg-medium", text: "text-medium" },
  { value: "low", label: "Low", color: "bg-low", text: "text-low" },
];

export const SORTS = [
  { value: "created_desc", label: "Newest first" },
  { value: "created_asc", label: "Oldest first" },
  { value: "due_asc", label: "Due soonest" },
  { value: "priority", label: "Highest priority" },
];

export const statusOf = (v) => STATUSES.find((s) => s.value === v) || STATUSES[0];
export const priorityOf = (v) => PRIORITIES.find((p) => p.value === v) || PRIORITIES[1];
